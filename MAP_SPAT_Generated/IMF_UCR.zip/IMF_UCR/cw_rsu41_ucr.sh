#!/bin/sh
# ddk 20231013

#set -x
SUT_IPV6_ADDR="[::1]"
SUT_IPV4_ADDR="127.0.0.1"
SUT_IP_PORT="1516"
MSG_DLY1="1.0"

MAP="./IMF_UCR/cw_ucr1_MAP.txt"
SSM="./IMF_UCR/cw_ucr1_SSM.txt"
SDSM="./IMF_UCR/cw_ucr1_SDSM.txt"

# Loop through Red, Green, and Yellow files from 499 to 0
RED_PREFIX="./IMF_UCR/cw_ucr1_imf_Red"
GRN_PREFIX="./IMF_UCR/cw_ucr1_imf_Grn"
YEL_PREFIX="./IMF_UCR/cw_ucr1_imf_Yel"

# Function to send SPAT files for a given color and range
send_spat_files() {
    local color_prefix=$1
    local start=$2
    local end=$3

    for i in $(seq $start -1 $end); do
        # Send the MAP file before each SPAT file
        echo "Sending MAP file: $MAP" | tee -a /var/log/imf_script.log
        cat $MAP | socat -t0 stdin UDP6-DATAGRAM:$SUT_IPV6_ADDR:$SUT_IP_PORT
        
        # Construct the filename for the current SPAT file
        file="${color_prefix}${i}.txt"

        # Check if file exists before sending
        if [ ! -f "$file" ]; then
            echo "Error: File $file not found!" | tee -a /var/log/imf_script.log
            continue
        fi

        # Send the SPAT file
        echo "Sending file: $file" | tee -a /var/log/imf_script.log
        cat $file | socat -t0 stdin UDP6-DATAGRAM:$SUT_IPV6_ADDR:$SUT_IP_PORT
        
        # Log sending
        echo "Sent file $file to $SUT_IPV6_ADDR:$SUT_IP_PORT" >> /var/log/imf_script.log
        sleep $MSG_DLY1
    done
}

# Main script logic
while [ true ]
do
    # Send Red SPAT files from Red499.txt to Red0.txt
    send_spat_files $RED_PREFIX 499 0

    # Send Green SPAT files from Grn499.txt to Grn0.txt
    send_spat_files $GRN_PREFIX 499 0

    # Send Yellow SPAT files from Yel499.txt to Yel0.txt
    send_spat_files $YEL_PREFIX 499 0

    sleep $MSG_DLY1
done

exit 0
